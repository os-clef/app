// grab elements
const jokeText = document.querySelector('.joke-text');
const yesBtn = document.querySelector('.yes-btn');
const noBtn = document.querySelector('.no-btn');

// jokes + song file mapping
const jokes = [
  { text: "Pero mahal mo pa?", song: "song1.mp3" },
  { text: "Ang tanong minahal kaba?", song: "song2.mp3" },
  { text: "Sa tingin mo, ikaw ang first and greatest love niya?", song: "song3.mp3" },
  { text: "May pag-asa kaba sa kanya?", song: "song4.mp3" },
  { text: "Mag coconfess kana", song: "song5.mp3" },
  { text: "Handa kabang magpaka tanga para sa taong mahal mo?", song: "song6.mp3" },
  { text: "Pasar imong score sa exam?", song: "song7.mp3" },
  { text: "With honor?", song: "song8.mp3" },
  { text: "Kamahal mahal kaba?", song: "song9.mp3" },
  { text: "Ikaw yung nandyan pero iba yung pinili, aray ko", song: "song10.mp3" }
];

let currentIndex = 0;

// preload all songs
const preloadedSongs = {};
jokes.forEach(joke => {
  const audio = new Audio();
  audio.src = joke.song;
  preloadedSongs[joke.song] = audio;
});

// show first joke
showJoke();

// Yes button → next joke + pop effect
yesBtn.addEventListener('click', () => {
  yesBtn.classList.add("pop");
  setTimeout(() => yesBtn.classList.remove("pop"), 300);
  
  currentIndex++;
  if (currentIndex >= jokes.length) currentIndex = 0;
  
  stopAllSongs();
  showJoke();
});

// No button → play song + shake + pop effect
noBtn.addEventListener('click', () => {
  noBtn.classList.add("pop");
  setTimeout(() => noBtn.classList.remove("pop"), 300);
  
  playSong(jokes[currentIndex].song);
  
  jokeText.classList.add("shake");
  setTimeout(() => jokeText.classList.remove("shake"), 500);
});

// show joke text with fade-in animation
function showJoke() {
  jokeText.classList.remove("show");
  jokeText.innerText = jokes[currentIndex].text;
  setTimeout(() => jokeText.classList.add("show"), 50);
}

// play specific preloaded song
function playSong(songFile) {
  const audio = preloadedSongs[songFile];
  if (!audio) return;
  
  audio.currentTime = 0;
  audio.play().catch(err => console.log(err));
  
  // stop other songs that might be playing
  Object.keys(preloadedSongs).forEach(key => {
    if (key !== songFile) {
      preloadedSongs[key].pause();
      preloadedSongs[key].currentTime = 0;
    }
  });
}

// stop all songs
function stopAllSongs() {
  Object.values(preloadedSongs).forEach(audio => {
    audio.pause();
    audio.currentTime = 0;
  });
}