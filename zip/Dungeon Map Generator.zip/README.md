This dungeon map generator implements a Wave Function Collapse algorithm made with [Claude AI](https://anthropic.com) and [Spck Editor](https://spck.io).

## Steps

1. Initial dungeon setup with patterns and constraints
2. Seeding the map with random rooms
3. Implementing the WFC algorithm
4. Making sure all regions are connected
5. Removing dead ends

## Development

This project is a WIP. Star the [github repo](https://github.com/spck-labs/Dungeon-Map-Generator) if you want to see more.

The following prompt was used to generate the initial code for this game.

```
Create a procedural generated dungeon crawler map which utilizes wave function collapse algorithm. 
- the generated map should be a multi-line string
- the generated map should have rooms and doors with interesting wall layouts
- the generated map should have no dead areas, dead areas should be removed from the map
- the generated map should all be connected and its possible to traverse from one end to the other
- the map dimension should be 48x48 with a border
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Special thanks to Anthropic for creating Claude AI
