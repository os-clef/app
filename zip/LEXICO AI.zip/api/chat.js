// Get references to HTML elements
const chatContainer = document.getElementById('chat-container');
const userInput = document.getElementById('user-input');
const inputContainer = document.getElementById('input-container');

// Send user input to backend and get the response
async function sendMessage() {
  const message = userInput.value.trim();

  if (!message) {
    alert("Please type a message.");
    return;
  }

  // Add user message to chat container
  chatContainer.innerHTML += `<div class="message user"><strong>You:</strong> ${message}</div>`;

  // Show loading circle (this simulates the AI typing)
  const loadingCircle = document.createElement("div");
  loadingCircle.className = "loading-circle";
  chatContainer.appendChild(loadingCircle);
  chatContainer.scrollTop = chatContainer.scrollHeight; // Scroll to bottom

  // Clear the input field
  userInput.value = "";

  try {
    // Send message to backend API
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();

    // Remove loading circle after receiving the response
    chatContainer.removeChild(loadingCircle);

    // Display the response from the bot
    const botResponse = data.message || "Sorry, something went wrong.";
    chatContainer.innerHTML += `<div class="message bot"><strong>LEXICO AI:</strong> ${botResponse}</div>`;
    chatContainer.scrollTop = chatContainer.scrollHeight; // Scroll to bottom
  } catch (error) {
    console.error("Error:", error);
    chatContainer.removeChild(loadingCircle);
    chatContainer.innerHTML += `<div class="message bot"><strong>LEXICO AI:</strong> Sorry, something went wrong.</div>`;
  }
}

// Event listener to send message when the "Send" button is clicked
document.querySelector("button").addEventListener("click", sendMessage);

// Optional: Allow pressing Enter to send the message
userInput.addEventListener("keydown", function(event) {
  if (event.key === "Enter") {
    sendMessage();
  }
});