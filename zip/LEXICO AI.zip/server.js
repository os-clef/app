const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: process.env.sk - proj - ZuWaVhN9GWCRt2cja6bwPjiB3hBC6etsMi_voAz - mjFqzs_d57iZJ6ixG8XWag1qTvVwOu2xyuT3BlbkFJFyvUMDvcV6afyhTBuWbUO2sbPI - pFARtf6tvrqNXEAHhT5ujlPfdNX4uIDjOVO3hkoRqGxb0YA, // Securely access your API key
});
const openai = new OpenAIApi(configuration);

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { message } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required" });
  }

  try {
    const response = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: message,
      max_tokens: 150,
      temperature: 0.7,
    });

    const botMessage = response.data.choices[0].text.trim();
    res.status(200).json({ message: botMessage });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};
const express = require('express');
const fetch = require('node-fetch'); // Or use axios for API calls
const app = express();
const port = process.env.PORT || 7700;

app.use(express.static('public')); // Serve static files from 'public' folder
app.use(express.json()); // Middleware to parse JSON bodies

// OpenAI API endpoint to handle messages
app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;

  if (!userMessage) {
    return res.status(400).json({ error: 'Message is required' });
  }

  try {
    const openAiResponse = await fetch('https://api.openai.com/v1/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.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}`, // Use environment variable
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo', // or the version you're using
        prompt: userMessage,
        max_tokens: 150,
      }),
    });
    const data = await openAiResponse.json();
    const message = data.choices[0].text.trim();

    res.json({ message });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
const express = require('express');
const fetch = require('node-fetch');
const app = express();
const port = process.env.PORT || 5000;

app.use(express.static('public'));
app.use(express.json());

app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;

  if (!userMessage) {
    return res.status(400).json({ error: 'Message is required' });
  }

  try {
    const openAiResponse = await fetch('https://api.openai.com/v1/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer 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', // your API key here
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo', // or whichever model you want to use
        prompt: userMessage,
        max_tokens: 150,
      }),
    });

    const data = await openAiResponse.json();
    const message = data.choices[0].text.trim();

    res.json({ message });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});