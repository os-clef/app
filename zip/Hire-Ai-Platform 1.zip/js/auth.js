// Authentication functionality
document.addEventListener('DOMContentLoaded', function() {
  // Set up authentication event listeners
  setupAuthEventListeners();
});

// Set up authentication event listeners
function setupAuthEventListeners() {
  // Login and Signup buttons
  document.getElementById('login-btn').addEventListener('click', function() {
    showAuthModal();
    switchAuthTab('login');
  });
  
  document.getElementById('signup-btn').addEventListener('click', function() {
    showAuthModal();
    switchAuthTab('register');
  });
  
  // Close auth modal
  document.getElementById('close-auth-modal').addEventListener('click', function() {
    hideAuthModal();
  });
  
  // Auth tab switching
  document.querySelectorAll('.auth-tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const tab = this.getAttribute('data-auth-tab');
      switchAuthTab(tab);
    });
  });
  
  // Login form submission
  document.getElementById('login-submit-btn').addEventListener('click', function() {
    loginUser();
  });
  
  // Register form submission
  document.getElementById('register-submit-btn').addEventListener('click', function() {
    registerUser();
  });
  
  // Forgot password link
  document.getElementById('forgot-password-link').addEventListener('click', function(e) {
    e.preventDefault();
    forgotPassword();
  });
  
  // Close modal when clicking outside
  document.getElementById('auth-modal').addEventListener('click', function(e) {
    if (e.target === this) {
      hideAuthModal();
    }
  });
}

// Show authentication modal
function showAuthModal() {
  document.getElementById('auth-modal').classList.add('active');
}

// Hide authentication modal
function hideAuthModal() {
  document.getElementById('auth-modal').classList.remove('active');
}

// Switch between login and register tabs
function switchAuthTab(tab) {
  // Update active tab button
  document.querySelectorAll('.auth-tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`.auth-tab-btn[data-auth-tab="${tab}"]`).classList.add('active');
  
  // Show corresponding form
  document.querySelectorAll('.auth-form').forEach(form => {
    form.classList.remove('active');
  });
  document.getElementById(`${tab}-form`).classList.add('active');
}

// Login user
function loginUser() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const role = document.getElementById('login-role').value;
  
  // Basic validation
  if (!email || !password) {
    showNotification('Please fill in all fields.', 'error');
    return;
  }
  
  if (!isValidEmail(email)) {
    showNotification('Please enter a valid email address.', 'error');
    return;
  }
  
  // Simulate API call
  simulateAPICall(() => {
    // Success
    hideAuthModal();
    
    if (role === 'candidate') {
      showUserDashboard();
      showNotification('Login successful! Welcome back.', 'success');
    } else {
      showCompanyDashboard();
      showNotification('Login successful! Welcome to your company dashboard.', 'success');
    }
    
    // Clear form
    document.getElementById('login-email').value = '';
    document.getElementById('login-password').value = '';
  });
}

// Register user
function registerUser() {
  const name = document.getElementById('register-name').value.trim();
  const email = document.getElementById('register-email').value.trim();
  const password = document.getElementById('register-password').value;
  const role = document.getElementById('register-role').value;
  
  // Basic validation
  if (!name || !email || !password) {
    showNotification('Please fill in all fields.', 'error');
    return;
  }
  
  if (!isValidEmail(email)) {
    showNotification('Please enter a valid email address.', 'error');
    return;
  }
  
  if (password.length < 6) {
    showNotification('Password must be at least 6 characters long.', 'error');
    return;
  }
  
  // Simulate API call
  simulateAPICall(() => {
    // Success
    hideAuthModal();
    
    if (role === 'candidate') {
      showUserDashboard();
      showNotification('Account created successfully! Welcome to Hire AI.', 'success');
    } else {
      showCompanyDashboard();
      showNotification('Company account created successfully!', 'success');
    }
    
    // Clear form
    document.getElementById('register-name').value = '';
    document.getElementById('register-email').value = '';
    document.getElementById('register-password').value = '';
  });
}

// Forgot password flow
function forgotPassword() {
  const email = prompt('Please enter your email address to reset your password:');
  
  if (email && isValidEmail(email)) {
    // Simulate sending reset email
    simulateAPICall(() => {
      showNotification('Password reset instructions have been sent to your email.', 'success');
    });
  } else if (email) {
    showNotification('Please enter a valid email address.', 'error');
  }
}

// Validate email format
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Simulate API call with delay
function simulateAPICall(callback) {
  // Show loading state
  const submitBtns = document.querySelectorAll('#login-submit-btn, #register-submit-btn');
  submitBtns.forEach(btn => {
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;
    
    // Simulate network delay
    setTimeout(() => {
      btn.innerHTML = originalText;
      btn.disabled = false;
      callback();
    }, 1500);
  });
}