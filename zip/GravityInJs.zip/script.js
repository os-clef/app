const tapThis = document.getElementById("tapThis");
const ball = document.querySelector(".ball");
const box = document.querySelector("canvas"); // The box element (ground)
let gravity = 0.2; // Gravity force
let velocityY = 0; // Initial vertical velocity
let posY = 0; // Initial position at the top
let isJumping = false; // Check if ball is in jump

function tap() {
  if (!isJumping) { // Only allow jump if not already jumping
    velocityY = -5; // Initial jump velocity when tapped
    isJumping = true; // Set jumping state to true
  }
}

function update() {
  // Apply gravity to vertical speed
  velocityY += gravity;
  
  // Update vertical position
  posY += velocityY;
  
  // Check for ground collision (the box top)
  const boxTop = box.offsetTop; // The top of the box
  const ballHeight = ball.offsetHeight;
  
  if (posY >= boxTop - ballHeight) {
    posY = boxTop - ballHeight; // Stop at the ground level
    velocityY = 0; // Reset velocity
    isJumping = false; // Reset jumping state
  }
  
  // Apply updated position to the ball (assuming it's vertically aligned)
  ball.style.transform = `translateY(${posY}px)`;
  
  requestAnimationFrame(update); // Call update again on next frame
}

// Start updating once DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  posY = box.offsetTop - ball.offsetHeight; // Initialize starting position just above ground
  requestAnimationFrame(update);
});

// Event listener for tapping/clicking
tapThis.addEventListener("click", tap);