// script.js

// Load models from FaceAPI.js
async function loadModels() {
  await faceapi.nets.ssdMobilenetv1.loadFromUri('/models');
  await faceapi.nets.faceRecognitionNet.loadFromUri('/models');
  await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
}

// Match faces
async function scanFaces() {
  const queryFaceInput = document.getElementById('query-face').files[0];
  const bulkPhotosInput = document.getElementById('bulk-photos').files;

  if (!queryFaceInput || bulkPhotosInput.length === 0) {
    alert('Please upload both a query face and bulk photos.');
    return;
  }

  const queryImage = await faceapi.bufferToImage(queryFaceInput);
  const queryDescriptor = await getFaceDescriptor(queryImage);

  const resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '<h3>Matched Photos:</h3>';

  for (const photo of bulkPhotosInput) {
    const bulkImage = await faceapi.bufferToImage(photo);
    const bulkDescriptor = await getFaceDescriptor(bulkImage);

    if (bulkDescriptor && queryDescriptor) {
      const distance = faceapi.euclideanDistance(queryDescriptor, bulkDescriptor);
      if (distance < 0.6) { // Match threshold
        resultsDiv.innerHTML += `<p>${photo.name} - Match</p>`;
      } else {
        resultsDiv.innerHTML += `<p>${photo.name} - No Match</p>`;
      }
    }
  }
}

// Extract face descriptor
async function getFaceDescriptor(image) {
  const detections = await faceapi.detectSingleFace(image).withFaceLandmarks().withFaceDescriptor();
  return detections ? detections.descriptor : null;
}

// Set up event listeners
document.getElementById('start-scan').addEventListener('click