## Fish Flocking

A simple animated background of fish swimming around. This lab uses vanilla JavaScript using a vanilla module style of programming and demonstrates how to draw using the Canvas APIs.