function GetVideo() {
  var search_value = document.getElementById("search").value;
  document.getElementById("video").src = search_value;
  document.getElementById("downloadBtn").download = search_value;
  document.getElementById("downloadBtn").href = search_value;
  var vname = document.getElementById("video").src.value;
  document.getElementById("h2").innerHTML = search_value;
}