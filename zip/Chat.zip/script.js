document.getElementById('chat-form').addEventListener('submit', function(e) {
  e.preventDefault();

  const messageInput = document.getElementById('message-input');
  const messageText = messageInput.value;

  // Create a message div
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('my-message');
  messageDiv.textContent = messageText;

  // Append message to chat messages
  document.getElementById('chat-messages').appendChild(messageDiv);

  // Clear the input
  messageInput.value = '';

  // Scroll to the bottom
  const messagesContainer = document.getElementById('chat-messages');
  messagesContainer.scrollTop = messagesContainer.scrollHeight;

  // Simulate receiving a message from a friend (for demo purposes)
  setTimeout(() => {
    const friendMessageDiv = document.createElement('div');
    friendMessageDiv.classList.add('friend-message');
    friendMessageDiv.textContent = "Friend: " + "Hello!"; // Simulating a static response
    messagesContainer.appendChild(friendMessageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }, 1000);
});