// Update your frontend to use the API
async function displayProducts() {
  try {
    const response = await fetch('http://localhost:3000/api/products');
    const products = await response.json();
    
    productsGrid.innerHTML = '';
    
    products.forEach(product => {
      const productCard = document.createElement('div');
      productCard.className = 'product-card';
      
      productCard.innerHTML = `
        <div class="product-image">
          <i class="fas ${getProductIcon(product.category)}"></i>
        </div>
        <div class="product-info">
          <h3 class="product-title">${product.name}</h3>
          <p class="product-price">$${product.price.toFixed(2)}</p>
          <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
        </div>
      `;
      
      productsGrid.appendChild(productCard);
    });
    
    // Add event listeners
    document.querySelectorAll('.add-to-cart').forEach(button => {
      button.addEventListener('click', async (e) => {
        const productId = parseInt(e.target.getAttribute('data-id'));
        
        // In a real app, you'd have user authentication
        const userId = 'user123'; // Temporary user ID
        
        try {
          await fetch('http://localhost:3000/api/cart', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              userId,
              productId,
              quantity: 1
            })
          });
          
          updateCartCount(userId);
        } catch (err) {
          console.error('Error adding to cart:', err);
        }
      });
    });
  } catch (err) {
    console.error('Error fetching products:', err);
  }
}

async function updateCartCount(userId) {
  try {
    const response = await fetch(`http://localhost:3000/api/cart/${userId}`);
    const cart = await response.json();
    cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0);
  } catch (err) {
    console.error('Error fetching cart:', err);
  }
}

// Helper function to get icons
function getProductIcon(category) {
  const icons = {
    'Fruits': 'fa-apple-alt',
    'Dairy': 'fa-wine-bottle',
    'Bakery': 'fa-bread-slice',
    'Meat': 'fa-drumstick-bite',
    'Vegetables': 'fa-carrot'
  };
  return icons[category] || 'fa-shopping-bag';
}