// AI-Powered Interview Simulation
class AIInterviewer {
  constructor() {
    this.currentQuestion = 0;
    this.userResponses = [];
    this.analysisResults = {};
    this.isInterviewActive = false;
  }
  
  startInterview(position = 'Frontend Developer') {
    this.isInterviewActive = true;
    this.currentQuestion = 0;
    this.userResponses = [];
    this.analysisResults = {
      technical: { score: 0, feedback: [] },
      communication: { score: 0, feedback: [] },
      problemSolving: { score: 0, feedback: [] },
      culturalFit: { score: 0, feedback: [] }
    };
    
    showAISimulationInterface();
    this.askQuestion();
    
    // Start analysis sensors
    this.startBehaviorAnalysis();
    this.startVoiceAnalysis();
    this.startFacialExpressionAnalysis();
  }
  
  askQuestion() {
    const questions = this.getQuestionsForPosition();
    if (this.currentQuestion < questions.length) {
      const question = questions[this.currentQuestion];
      this.displayAIQuestion(question);
      this.startResponseTimer();
    } else {
      this.endInterview();
    }
  }
  
  getQuestionsForPosition() {
    const questionBanks = {
      'Frontend Developer': [
        "Explain the difference between let, const, and var in JavaScript.",
        "How would you optimize a slow React application?",
        "Describe your approach to responsive design.",
        "What's your experience with testing frameworks?",
        "How do you handle cross-browser compatibility issues?"
      ],
      'Backend Developer': [
        "Explain RESTful API design principles.",
        "How do you handle database migrations?",
        "Describe your experience with microservices.",
        "What security measures do you implement in APIs?",
        "How do you optimize database queries?"
      ],
      'Full Stack Developer': [
        "Describe your full-stack architecture experience.",
        "How do you ensure consistency between frontend and backend?",
        "What's your approach to API design?",
        "How do you handle authentication across stacks?",
        "Describe your deployment experience."
      ]
    };
    
    return questionBanks['Frontend Developer']; // Default for demo
  }
  
  displayAIQuestion(question) {
    const interviewContainer = document.getElementById('ai-interview-container');
    interviewContainer.innerHTML = `
            <div class="ai-interviewer">
                <div class="ai-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="ai-question">
                    <p>${question}</p>
                    <div class="question-meta">
                        <span>Technical Question</span>
                        <span>Expected time: 2-3 minutes</span>
                    </div>
                </div>
            </div>
            <div class="user-response-area">
                <textarea placeholder="Type your response here..." id="user-response"></textarea>
                <div class="response-controls">
                    <button class="btn btn-outline" id="skip-question">Skip</button>
                    <button class="btn btn-primary" id="submit-response">Submit Response</button>
                </div>
            </div>
            <div class="live-analysis">
                <h4>Live Analysis</h4>
                <div class="analysis-metrics">
                    <div class="metric">
                        <span>Confidence Level</span>
                        <div class="progress-container">
                            <div class="progress-bar" id="confidence-meter" style="width: 0%"></div>
                        </div>
                    </div>
                    <div class="metric">
                        <span>Technical Accuracy</span>
                        <div class="progress-container">
                            <div class="progress-bar" id="accuracy-meter" style="width: 0%"></div>
                        </div>
                    </div>
                    <div class="metric">
                        <span>Communication Skills</span>
                        <div class="progress-container">
                            <div class="progress-bar" id="communication-meter" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    
    // Add event listeners
    document.getElementById('submit-response').addEventListener('click', () => {
      this.handleUserResponse();
    });
    
    document.getElementById('skip-question').addEventListener('click', () => {
      this.skipQuestion();
    });
  }
  
  handleUserResponse() {
    const response = document.getElementById('user-response').value.trim();
    if (response) {
      this.userResponses.push({
        question: this.currentQuestion,
        response: response,
        timestamp: new Date().toISOString()
      });
      
      // Analyze response
      this.analyzeResponse(response);
      
      this.currentQuestion++;
      setTimeout(() => this.askQuestion(), 1000);
    } else {
      showNotification('Please provide a response before submitting.', 'warning');
    }
  }
  
  analyzeResponse(response) {
    // Simulate AI analysis
    const technicalScore = Math.min(100, response.length * 2 + Math.random() * 30);
    const communicationScore = Math.min(100, this.analyzeCommunication(response));
    const confidenceScore = Math.min(100, this.analyzeConfidence(response));
    
    // Update analysis results
    this.analysisResults.technical.score =
      (this.analysisResults.technical.score * this.currentQuestion + technicalScore) / (this.currentQuestion + 1);
    
    this.analysisResults.communication.score =
      (this.analysisResults.communication.score * this.currentQuestion + communicationScore) / (this.currentQuestion + 1);
    
    // Provide feedback
    this.generateFeedback(response, technicalScore, communicationScore);
    
    // Update UI
    this.updateAnalysisMeters(technicalScore, communicationScore, confidenceScore);
  }
  
  analyzeCommunication(response) {
    // Simple analysis based on response characteristics
    let score = 50; // Base score
    
    // Positive factors
    if (response.length > 100) score += 10;
    if (response.includes('example') || response.includes('for instance')) score += 15;
    if (this.countParagraphs(response) > 1) score += 10;
    
    // Negative factors
    if (response.length < 50) score -= 20;
    if (this.countSpellingErrors(response) > 3) score -= 15;
    
    return Math.max(0, Math.min(100, score));
  }
  
  analyzeConfidence(response) {
    // Analyze confidence indicators
    let confidenceIndicators = 0;
    const confidenceWords = ['confident', 'certain', 'definitely', 'clearly', 'obviously'];
    
    confidenceWords.forEach(word => {
      if (response.toLowerCase().includes(word)) confidenceIndicators++;
    });
    
    return Math.min(100, 50 + (confidenceIndicators * 10));
  }
  
  countParagraphs(text) {
    return text.split('\n\n').length;
  }
  
  countSpellingErrors(text) {
    // Simple error detection (in real app, use a library)
    const commonErrors = ['teh', 'adn', 'recieve', 'seperate'];
    let errors = 0;
    
    commonErrors.forEach(error => {
      if (text.toLowerCase().includes(error)) errors++;
    });
    
    return errors;
  }
  
  generateFeedback(response, technicalScore, communicationScore) {
    const feedback = [];
    
    if (technicalScore < 70) {
      feedback.push('Consider providing more technical details and examples.');
    }
    
    if (communicationScore < 60) {
      feedback.push('Try to structure your response more clearly with examples.');
    }
    
    if (response.length < 100) {
      feedback.push('Your response could be more detailed. Aim for 100-200 words.');
    }
    
    this.analysisResults.technical.feedback.push(feedback.join(' '));
  }
  
  updateAnalysisMeters(technical, communication, confidence) {
    const meters = {
      'accuracy-meter': technical,
      'communication-meter': communication,
      'confidence-meter': confidence
    };
    
    Object.keys(meters).forEach(meterId => {
      const meter = document.getElementById(meterId);
      if (meter) {
        meter.style.width = `${meters[meterId]}%`;
        
        // Color coding
        if (meters[meterId] > 80) {
          meter.style.background = '#10b981';
        } else if (meters[meterId] > 60) {
          meter.style.background = '#f59e0b';
        } else {
          meter.style.background = '#ef4444';
        }
      }
    });
  }
  
  startResponseTimer() {
    let timeLeft = 180; // 3 minutes
    const timerElement = document.getElementById('response-timer');
    if (!timerElement) return;
    
    const timerInterval = setInterval(() => {
      timeLeft--;
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;
      
      timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
      
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        this.handleTimeUp();
      }
      
      // Warning colors
      if (timeLeft < 60) {
        timerElement.style.color = '#ef4444';
      } else if (timeLeft < 120) {
        timerElement.style.color = '#f59e0b';
      }
    }, 1000);
  }
  
  handleTimeUp() {
    showNotification('Time is up! Moving to next question.', 'warning');
    this.currentQuestion++;
    setTimeout(() => this.askQuestion(), 2000);
  }
  
  skipQuestion() {
    showNotification('Question skipped. This may affect your overall score.', 'warning');
    this.currentQuestion++;
    setTimeout(() => this.askQuestion(), 1000);
  }
  
  startBehaviorAnalysis() {
    // Simulate behavior analysis
    setInterval(() => {
      if (this.isInterviewActive) {
        this.updateBehaviorMetrics();
      }
    }, 3000);
  }
  
  startVoiceAnalysis() {
    // Simulate voice analysis
    console.log('Voice analysis started - would use Web Audio API in real implementation');
  }
  
  startFacialExpressionAnalysis() {
    // Simulate facial expression analysis
    console.log('Facial expression analysis started - would use WebRTC in real implementation');
  }
  
  updateBehaviorMetrics() {
    // Simulate real-time behavior metrics
    const metrics = {
      eyeContact: 70 + Math.random() * 30,
      posture: 60 + Math.random() * 40,
      engagement: 75 + Math.random() * 25
    };
    
    // Update UI if elements exist
    Object.keys(metrics).forEach(metric => {
      const element = document.getElementById(`${metric}-metric`);
      if (element) {
        element.textContent = Math.round(metrics[metric]);
      }
    });
  }
  
  endInterview() {
    this.isInterviewActive = false;
    this.generateFinalReport();
    showNotification('Interview completed! Generating your detailed report...', 'success');
  }
  
  generateFinalReport() {
    const report = {
      overallScore: this.calculateOverallScore(),
      strengths: this.identifyStrengths(),
      areasForImprovement: this.identifyImprovementAreas(),
      detailedBreakdown: this.analysisResults,
      recommendations: this.generateRecommendations()
    };
    
    this.displayFinalReport(report);
  }
  
  calculateOverallScore() {
    const weights = { technical: 0.4, communication: 0.3, problemSolving: 0.2, culturalFit: 0.1 };
    let total = 0;
    
    Object.keys(weights).forEach(category => {
      total += this.analysisResults[category].score * weights[category];
    });
    
    return Math.round(total);
  }
  
  identifyStrengths() {
    const strengths = [];
    if (this.analysisResults.technical.score > 80) strengths.push('Strong technical knowledge');
    if (this.analysisResults.communication.score > 75) strengths.push('Effective communication');
    if (this.userResponses.length > 0) strengths.push('Good response rate');
    
    return strengths.length > 0 ? strengths : ['Consistent performance across areas'];
  }
  
  identifyImprovementAreas() {
    const improvements = [];
    if (this.analysisResults.technical.score < 70) improvements.push('Technical depth');
    if (this.analysisResults.communication.score < 65) improvements.push('Communication clarity');
    if (this.analysisResults.problemSolving.score < 60) improvements.push('Problem-solving approach');
    
    return improvements.length > 0 ? improvements : ['Minor refinements needed'];
  }
  
  generateRecommendations() {
    return [
      'Practice technical interviews with our AI coach',
      'Review fundamental concepts in your field',
      'Work on structuring your responses more clearly',
      'Consider taking our communication skills course'
    ];
  }
  
  displayFinalReport(report) {
    const interviewContainer = document.getElementById('ai-interview-container');
    interviewContainer.innerHTML = `
            <div class="interview-report">
                <h3>Interview Report</h3>
                <div class="score-card">
                    <div class="overall-score">
                        <h4>Overall Score</h4>
                        <div class="score-circle">${report.overallScore}/100</div>
                    </div>
                    <div class="category-scores">
                        <div class="category-score">
                            <span>Technical</span>
                            <div class="progress-container">
                                <div class="progress-bar" style="width: ${report.detailedBreakdown.technical.score}%"></div>
                            </div>
                            <span>${Math.round(report.detailedBreakdown.technical.score)}%</span>
                        </div>
                        <div class="category-score">
                            <span>Communication</span>
                            <div class="progress-container">
                                <div class="progress-bar" style="width: ${report.detailedBreakdown.communication.score}%"></div>
                            </div>
                            <span>${Math.round(report.detailedBreakdown.communication.score)}%</span>
                        </div>
                    </div>
                </div>
                
                <div class="report-section">
                    <h4>Strengths</h4>
                    <ul>
                        ${report.strengths.map(strength => `<li>${strength}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="report-section">
                    <h4>Areas for Improvement</h4>
                    <ul>
                        ${report.areasForImprovement.map(area => `<li>${area}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="report-section">
                    <h4>Recommendations</h4>
                    <ul>
                        ${report.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="report-actions">
                    <button class="btn btn-primary" id="save-report">Save Report</button>
                    <button class="btn btn-outline" id="practice-again">Practice Again</button>
                    <button class="btn btn-secondary" id="share-report">Share with Coach</button>
                </div>
            </div>
        `;
    
    // Add event listeners for report actions
    document.getElementById('save-report').addEventListener('click', () => {
      this.saveReport(report);
    });
    
    document.getElementById('practice-again').addEventListener('click', () => {
      this.startInterview();
    });
    
    document.getElementById('share-report').addEventListener('click', () => {
      this.shareReport(report);
    });
  }
  
  saveReport(report) {
    // Simulate saving report
    showNotification('Interview report saved to your profile!', 'success');
  }
  
  shareReport(report) {
    // Simulate sharing
    showNotification('Report shared with your career coach!', 'success');
  }
}

// Initialize AI Interviewer
const aiInterviewer = new AIInterviewer();

// Export for global access
window.aiInterviewer = aiInterviewer;

function showAISimulationInterface() {
  // Create or show AI interview interface
  const existingInterface = document.getElementById('ai-interview-interface');
  if (!existingInterface) {
    const interviewHTML = `
            <section id="ai-interview-interface" class="active-page">
                <div class="interview-header">
                    <h2>AI Interview Simulation</h2>
                    <div class="interview-info">
                        <span>Position: Frontend Developer</span>
                        <span>Time: <span id="response-timer">03:00</span></span>
                    </div>
                </div>
                <div class="ai-interview-container" id="ai-interview-container">
                    <!-- Content will be populated by AIInterviewer -->
                </div>
                <div class="behavior-analysis">
                    <h4>Behavior Analysis</h4>
                    <div class="behavior-metrics">
                        <div class="metric">
                            <span>Eye Contact</span>
                            <span id="eyeContact-metric">75%</span>
                        </div>
                        <div class="metric">
                            <span>Posture</span>
                            <span id="posture-metric">80%</span>
                        </div>
                        <div class="metric">
                            <span>Engagement</span>
                            <span id="engagement-metric">85%</span>
                        </div>
                    </div>
                </div>
            </section>
        `;
    
    document.querySelector('.container').insertAdjacentHTML('beforeend', interviewHTML);
  } else {
    existingInterface.classList.add('active-page');
  }
  
  // Hide other pages
  document.querySelectorAll('.active-page').forEach(page => {
    if (!page.id.includes('interview')) {
      page.classList.remove('active-page');
    }
  });
}