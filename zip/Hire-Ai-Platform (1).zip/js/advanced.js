// Advanced Features JavaScript
document.addEventListener('DOMContentLoaded', function() {
  initAdvancedFeatures();
});

function initAdvancedFeatures() {
  // Initialize AI Proctoring
  initAIProctoring();
  
  // Initialize Voice Interface
  initVoiceInterface();
  
  // Initialize Real-time Collaboration
  initCollaboration();
  
  // Initialize VR Simulation
  initVRSimulation();
  
  // Initialize Notification System
  initNotificationSystem();
  
  // Initialize Advanced Analytics
  initAdvancedAnalytics();
  
  // Initialize Gamification
  initGamification();
  
  // Initialize Blockchain Verification
  initBlockchainVerification();
}

// AI Proctoring Enhancement
function initAIProctoring() {
  // Simulate AI proctoring metrics
  setInterval(() => {
    updateProctoringMetrics();
  }, 2000);
}

function updateProctoringMetrics() {
  const metrics = {
    focus: Math.floor(Math.random() * 100),
    integrity: 95 + Math.floor(Math.random() * 5),
    engagement: 70 + Math.floor(Math.random() * 30),
    performance: 80 + Math.floor(Math.random() * 20)
  };
  
  Object.keys(metrics).forEach(metric => {
    const element = document.getElementById(`${metric}-metric`);
    if (element) {
      element.textContent = metrics[metric];
      
      // Update color based on value
      if (metrics[metric] > 80) {
        element.style.color = '#10b981';
      } else if (metrics[metric] > 60) {
        element.style.color = '#f59e0b';
      } else {
        element.style.color = '#ef4444';
      }
    }
  });
}

// Voice Command Interface
function initVoiceInterface() {
  const voiceBtn = document.getElementById('voice-command-btn');
  const voiceFeedback = document.getElementById('voice-feedback');
  
  if (!voiceBtn) return;
  
  let recognition;
  try {
    recognition = new(window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.continuous = false;
    recognition.interimResults = true;
    
    recognition.onstart = function() {
      voiceBtn.classList.add('listening');
      voiceFeedback.textContent = 'Listening...';
      voiceFeedback.style.display = 'block';
    };
    
    recognition.onresult = function(event) {
      const transcript = Array.from(event.results)
        .map(result => result[0])
        .map(result => result.transcript)
        .join('');
      
      voiceFeedback.textContent = transcript;
      
      if (event.results[0].isFinal) {
        processVoiceCommand(transcript);
      }
    };
    
    recognition.onend = function() {
      voiceBtn.classList.remove('listening');
      setTimeout(() => {
        voiceFeedback.style.display = 'none';
      }, 2000);
    };
    
    recognition.onerror = function(event) {
      console.error('Speech recognition error', event.error);
      voiceBtn.classList.remove('listening');
      voiceFeedback.textContent = 'Error: ' + event.error;
      setTimeout(() => {
        voiceFeedback.style.display = 'none';
      }, 3000);
    };
    
    voiceBtn.addEventListener('click', function() {
      if (voiceBtn.classList.contains('listening')) {
        recognition.stop();
      } else {
        recognition.start();
      }
    });
  } catch (error) {
    console.log('Speech recognition not supported');
    voiceBtn.style.display = 'none';
  }
}

function processVoiceCommand(command) {
  command = command.toLowerCase();
  
  if (command.includes('start assessment')) {
    showNotification('Starting assessment as per voice command', 'success');
    // Start assessment logic here
  } else if (command.includes('open dashboard')) {
    showUserDashboard();
    showNotification('Opening dashboard', 'success');
  } else if (command.includes('show notifications')) {
    toggleNotificationCenter();
  } else if (command.includes('search jobs')) {
    const searchTerm = command.replace('search jobs', '').trim();
    if (searchTerm) {
      document.getElementById('job-search').value = searchTerm;
      searchJobs(searchTerm);
      showNotification(`Searching for: ${searchTerm}`, 'success');
    }
  } else {
    showNotification(`Voice command executed: ${command}`, 'info');
  }
}

// Real-time Collaboration
function initCollaboration() {
  // Simulate collaborative editing
  const codeEditor = document.getElementById('collaboration-code-editor');
  if (codeEditor) {
    codeEditor.addEventListener('input', function() {
      simulateCollaboratorTyping();
    });
  }
}

function simulateCollaboratorTyping() {
  const collaborators = ['AI Reviewer', 'Senior Developer', 'HR Manager'];
  const randomCollaborator = collaborators[Math.floor(Math.random() * collaborators.length)];
  
  // Simulate collaborator joining/leaving
  setInterval(() => {
    updateCollaboratorsList();
  }, 10000);
}

function updateCollaboratorsList() {
  const collaboratorsList = document.getElementById('collaborators-list');
  if (!collaboratorsList) return;
  
  const collaborators = ['You', 'AI Reviewer', 'Senior Developer'];
  const onlineCount = 1 + Math.floor(Math.random() * 2); // 1-3 online
  
  collaboratorsList.innerHTML = '';
  for (let i = 0; i < onlineCount; i++) {
    const collaborator = document.createElement('div');
    collaborator.className = 'collaborator';
    collaborator.innerHTML = `
            <i class="fas fa-circle" style="color: #10b981;"></i>
            ${collaborators[i]}
        `;
    collaboratorsList.appendChild(collaborator);
  }
}

// VR Simulation
function initVRSimulation() {
  const vrContainer = document.getElementById('vr-environment');
  if (!vrContainer) return;
  
  // Simulate VR environment interaction
  let rotation = 0;
  setInterval(() => {
    rotation += 0.5;
    vrContainer.style.background = `linear-gradient(${rotation}deg, #1e40af 0%, #7c3aed 50%, #ec4899 100%)`;
  }, 50);
  
  // Add VR control handlers
  document.querySelectorAll('.vr-control').forEach(control => {
    control.addEventListener('click', function() {
      const action = this.getAttribute('data-action');
      handleVRAction(action);
    });
  });
}

function handleVRAction(action) {
  const actions = {
    'look-around': 'Panning VR view',
    'interact': 'Interacting with object',
    'move': 'Moving in VR space',
    'menu': 'Opening VR menu'
  };
  
  showNotification(`VR Action: ${actions[action]}`, 'info');
}

// Notification System
function initNotificationSystem() {
  // Simulate incoming notifications
  setInterval(() => {
    if (Math.random() > 0.7) { // 30% chance every interval
      generateRandomNotification();
    }
  }, 30000); // Every 30 seconds
  
  // Notification center toggle
  const notificationBell = document.getElementById('notification-bell');
  const notificationCenter = document.getElementById('notification-center');
  
  if (notificationBell && notificationCenter) {
    notificationBell.addEventListener('click', function() {
      toggleNotificationCenter();
    });
  }
}

function toggleNotificationCenter() {
  const notificationCenter = document.getElementById('notification-center');
  notificationCenter.classList.toggle('active');
  
  // Mark all as read when opening
  if (notificationCenter.classList.contains('active')) {
    document.querySelectorAll('.notification-item.unread').forEach(item => {
      item.classList.remove('unread');
    });
    updateNotificationBadge(0);
  }
}

function generateRandomNotification() {
  const notifications = [
  {
    title: 'New Job Match',
    message: 'Google has a new Frontend Developer position that matches your skills',
    type: 'job'
  },
  {
    title: 'Assessment Reminder',
    message: 'Your Amazon assessment needs to be completed in 2 days',
    type: 'assessment'
  },
  {
    title: 'Skill Improvement',
    message: 'Your React skills have improved to 85% based on recent assessments',
    type: 'skill'
  },
  {
    title: 'New Message',
    message: 'You have a new message from the hiring team at Meta',
    type: 'message'
  }];
  
  const notification = notifications[Math.floor(Math.random() * notifications.length)];
  addNotification(notification);
  updateNotificationBadge();
}

function addNotification(notification) {
  const notificationList = document.getElementById('notification-list');
  if (!notificationList) return;
  
  const notificationItem = document.createElement('div');
  notificationItem.className = 'notification-item unread';
  notificationItem.innerHTML = `
        <strong>${notification.title}</strong>
        <p>${notification.message}</p>
        <div class="notification-time">Just now</div>
    `;
  
  notificationItem.addEventListener('click', function() {
    handleNotificationClick(notification.type);
    this.classList.remove('unread');
    updateNotificationBadge();
  });
  
  notificationList.insertBefore(notificationItem, notificationList.firstChild);
  
  // Keep only last 10 notifications
  if (notificationList.children.length > 10) {
    notificationList.removeChild(notificationList.lastChild);
  }
  
  updateNotificationBadge();
}

function updateNotificationBadge(count) {
  const badge = document.getElementById('notification-badge');
  if (!badge) return;
  
  if (count === undefined) {
    // Count unread notifications
    const unreadCount = document.querySelectorAll('.notification-item.unread').length;
    badge.textContent = unreadCount > 0 ? unreadCount : '';
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
  } else {
    badge.textContent = count > 0 ? count : '';
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

function handleNotificationClick(type) {
  switch (type) {
    case 'job':
      showUserDashboard();
      showUserTab('jobs');
      break;
    case 'assessment':
      showUserDashboard();
      showUserTab('assessments');
      break;
    case 'skill':
      showUserDashboard();
      showUserTab('skills');
      break;
    case 'message':
      // Open messaging interface
      showNotification('Opening messages...', 'info');
      break;
  }
}

// Advanced Analytics
function initAdvancedAnalytics() {
  // Initialize charts if Chart.js is available
  if (typeof Chart !== 'undefined') {
    initAnalyticsCharts();
  }
  
  // Real-time analytics updates
  setInterval(() => {
    updateRealTimeAnalytics();
  }, 5000);
}

function initAnalyticsCharts() {
  // Skill Progress Chart
  const skillCtx = document.getElementById('skill-progress-chart');
  if (skillCtx) {
    new Chart(skillCtx, {
      type: 'radar',
      data: {
        labels: ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js', 'Communication'],
        datasets: [{
          label: 'Current Skills',
          data: [85, 78, 92, 80, 70, 75],
          backgroundColor: 'rgba(37, 99, 235, 0.2)',
          borderColor: '#2563eb',
          pointBackgroundColor: '#2563eb'
        }, {
          label: 'Target Skills',
          data: [95, 90, 95, 90, 85, 90],
          backgroundColor: 'rgba(16, 185, 129, 0.2)',
          borderColor: '#10b981',
          pointBackgroundColor: '#10b981'
        }]
      },
      options: {
        scales: {
          r: {
            angleLines: { display: true },
            suggestedMin: 0,
            suggestedMax: 100
          }
        }
      }
    });
  }
  
  // Performance Trend Chart
  const trendCtx = document.getElementById('performance-trend-chart');
  if (trendCtx) {
    new Chart(trendCtx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Technical Skills',
          data: [65, 70, 75, 80, 82, 85],
          borderColor: '#2563eb',
          tension: 0.3
        }, {
          label: 'Communication',
          data: [60, 65, 68, 72, 75, 78],
          borderColor: '#10b981',
          tension: 0.3
        }, {
          label: 'Problem Solving',
          data: [70, 72, 75, 78, 80, 83],
          borderColor: '#f59e0b',
          tension: 0.3
        }]
      }
    });
  }
}

function updateRealTimeAnalytics() {
  // Simulate real-time data updates
  const metrics = document.querySelectorAll('.real-time-metric');
  metrics.forEach(metric => {
    const currentValue = parseInt(metric.textContent);
    const change = Math.floor(Math.random() * 10) - 2; // -2 to +7
    const newValue = Math.max(0, currentValue + change);
    metric.textContent = newValue;
    
    // Visual feedback
    if (change > 0) {
      metric.style.color = '#10b981';
      setTimeout(() => metric.style.color = '', 1000);
    } else if (change < 0) {
      metric.style.color = '#ef4444';
      setTimeout(() => metric.style.color = '', 1000);
    }
  });
}

// Gamification System
function initGamification() {
  // Load user XP and achievements
  loadUserProgress();
  
  // Simulate XP gains
  setInterval(() => {
    simulateXPGain();
  }, 60000); // Every minute
}

function loadUserProgress() {
  const userProgress = {
    xp: 1250,
    level: 3,
    nextLevelXP: 2000,
    achievements: ['First Assessment', 'Skill Master', 'Quick Learner']
  };
  
  document.getElementById('user-xp').textContent = userProgress.xp;
  document.getElementById('user-level').textContent = userProgress.level;
  document.getElementById('xp-progress').style.width =
    `${(userProgress.xp / userProgress.nextLevelXP) * 100}%`;
  
  // Display achievements
  const achievementsContainer = document.getElementById('achievements-container');
  if (achievementsContainer) {
    userProgress.achievements.forEach(achievement => {
      const achievementEl = document.createElement('div');
      achievementEl.className = 'achievement';
      achievementEl.innerHTML = `
                <i class="fas fa-trophy"></i>
                <span>${achievement}</span>
            `;
      achievementsContainer.appendChild(achievementEl);
    });
  }
}

function simulateXPGain() {
  const xpGain = Math.floor(Math.random() * 50) + 10; // 10-60 XP
  const currentXP = parseInt(document.getElementById('user-xp').textContent);
  const newXP = currentXP + xpGain;
  
  document.getElementById('user-xp').textContent = newXP;
  
  // Check for level up
  const level = parseInt(document.getElementById('user-level').textContent);
  const nextLevelXP = level * 1000;
  
  if (newXP >= nextLevelXP) {
    levelUp();
  }
  
  // Update progress bar
  const progress = (newXP % 1000) / 1000 * 100;
  document.getElementById('xp-progress').style.width = `${progress}%`;
  
  showNotification(`+${xpGain} XP gained!`, 'success');
}

function levelUp() {
  const levelElement = document.getElementById('user-level');
  const currentLevel = parseInt(levelElement.textContent);
  const newLevel = currentLevel + 1;
  
  levelElement.textContent = newLevel;
  showNotification(`🎉 Level Up! You reached level ${newLevel}`, 'success');
  
  // Add new achievement
  const achievements = ['Rising Star', 'Assessment Pro', 'Skill Champion', 'Interview Expert'];
  const newAchievement = achievements[Math.floor(Math.random() * achievements.length)];
  
  const achievementsContainer = document.getElementById('achievements-container');
  if (achievementsContainer) {
    const achievementEl = document.createElement('div');
    achievementEl.className = 'achievement';
    achievementEl.innerHTML = `
            <i class="fas fa-trophy"></i>
            <span>${newAchievement}</span>
        `;
    achievementsContainer.appendChild(achievementEl);
  }
}

// Blockchain Verification
function initBlockchainVerification() {
  // Simulate blockchain verification process
  simulateBlockchainVerification();
}

function simulateBlockchainVerification() {
  const blocks = document.querySelectorAll('.blockchain-block');
  let currentBlock = 0;
  
  const verificationInterval = setInterval(() => {
    if (currentBlock < blocks.length) {
      blocks[currentBlock].style.background = '#10b981';
      blocks[currentBlock].innerHTML += '<br><small>✓ Verified</small>';
      currentBlock++;
    } else {
      clearInterval(verificationInterval);
      document.getElementById('verification-status').textContent = 'All credentials verified on blockchain';
      document.getElementById('verification-status').style.color = '#10b981';
    }
  }, 1000);
}

// AI-Powered Resume Builder
function initResumeBuilder() {
  const templateOptions = document.querySelectorAll('.template-option');
  templateOptions.forEach(option => {
    option.addEventListener('click', function() {
      templateOptions.forEach(opt => opt.classList.remove('active'));
      this.classList.add('active');
      applyResumeTemplate(this.getAttribute('data-template'));
    });
  });
}

function applyResumeTemplate(template) {
  const resumePreview = document.getElementById('resume-preview');
  const templates = {
    modern: '<div class="resume-modern">Modern Template Applied</div>',
    professional: '<div class="resume-professional">Professional Template Applied</div>',
    creative: '<div class="resume-creative">Creative Template Applied</div>'
  };
  
  resumePreview.innerHTML = templates[template] || templates.modern;
  showNotification(`Applied ${template} resume template`, 'success');
}

// Advanced Search and Filtering
function initAdvancedSearch() {
  const filterChips = document.querySelectorAll('.filter-chip');
  filterChips.forEach(chip => {
    chip.addEventListener('click', function() {
      this.classList.toggle('active');
      applyFilters();
    });
  });
  
  // Real-time search
  const searchInput = document.getElementById('advanced-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', debounce(function() {
      performAdvancedSearch(this.value);
    }, 300));
  }
}

function applyFilters() {
  const activeFilters = Array.from(document.querySelectorAll('.filter-chip.active'))
    .map(chip => chip.textContent.trim());
  
  showNotification(`Applied filters: ${activeFilters.join(', ')}`, 'info');
  // In real implementation, this would filter the results
}

function performAdvancedSearch(query) {
  if (query.length > 2) {
    showNotification(`Searching for: ${query}`, 'info');
    // In real implementation, this would perform the search
  }
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Dark Mode Toggle - Fixed and Complete Version
function initDarkMode() {
  const darkModeToggle = document.getElementById('dark-mode-toggle');
  if (darkModeToggle) {
    // Load saved preference from localStorage
    const savedDarkMode = localStorage.getItem('darkMode');
    const isDarkMode = savedDarkMode === 'true';
    
    // Set initial state
    darkModeToggle.checked = isDarkMode;
    document.body.classList.toggle('dark-mode', isDarkMode);
    
    // Add event listener
    darkModeToggle.addEventListener('change', function() {
      const isDark = this.checked;
      document.body.classList.toggle('dark-mode', isDark);
      
      // Save to localStorage
      try {
        localStorage.setItem('darkMode', isDark);
        console.log('Dark mode preference saved:', isDark);
      } catch (error) {
        console.error('Error saving dark mode preference:', error);
        // Handle storage errors (e.g., localStorage full or disabled)
        showNotification('Could not save theme preference', 'error');
      }
      
      // Update UI elements that need special dark mode handling
      updateDarkModeElements(isDark);
    });
  }
  
  // Also create toggle button if it doesn't exist
  createDarkModeToggle();
}

// Create dark mode toggle button for easy access
function createDarkModeToggle() {
  if (!document.getElementById('dark-mode-toggle')) {
    const darkModeContainer = document.createElement('div');
    darkModeContainer.className = 'dark-mode-toggle-container';
    darkModeContainer.innerHTML = `
            <label class="dark-mode-switch">
                <input type="checkbox" id="dark-mode-toggle">
                <span class="slider round">
                    <i class="fas fa-sun"></i>
                    <i class="fas fa-moon"></i>
                </span>
            </label>
        `;
    
    // Add to page (top right corner)
    darkModeContainer.style.position = 'fixed';
    darkModeContainer.style.top = '20px';
    darkModeContainer.style.right = '20px';
    darkModeContainer.style.zIndex = '1000';
    
    document.body.appendChild(darkModeContainer);
    
    // Re-initialize with the new toggle
    initDarkMode();
  }
}

// Update specific elements for dark mode
function updateDarkModeElements(isDark) {
  // Update charts if they exist
  updateChartsForDarkMode(isDark);
  
  // Update code editors
  updateCodeEditorsForDarkMode(isDark);
  
  // Update any custom elements
  updateCustomElementsForDarkMode(isDark);
  
  // Send analytics event (if analytics are enabled)
  logDarkModeEvent(isDark);
}

// Enhanced dark mode styles
const darkModeStyles = `
/* Enhanced Dark Mode Styles */
.dark-mode {
    background: #0f172a !important;
    color: #e2e8f0 !important;
}

.dark-mode .card {
    background: #1e293b !important;
    color: #e2e8f0 !important;
    border-color: #334155 !important;
}

.dark-mode .form-control {
    background: #334155 !important;
    border-color: #475569 !important;
    color: #e2e8f0 !important;
}

.dark-mode .form-control::placeholder {
    color: #94a3b8 !important;
}

.dark-mode .btn-outline {
    border-color: #475569 !important;
    color: #e2e8f0 !important;
}

.dark-mode .btn-outline:hover {
    background: #475569 !important;
    color: #0f172a !important;
}

.dark-mode .sidebar {
    background: #1e293b !important;
}

.dark-mode .nav-links a {
    color: #e2e8f0 !important;
}

.dark-mode .nav-links a:hover,
.dark-mode .nav-links a.active {
    background: #334155 !important;
}

.dark-mode .progress-container {
    background: #334155 !important;
}

.dark-mode table {
    color: #e2e8f0 !important;
}

.dark-mode th {
    background: #334155 !important;
}

.dark-mode tr:hover {
    background: #334155 !important;
}

.dark-mode .modal-content {
    background: #1e293b !important;
    color: #e2e8f0 !important;
}

.dark-mode .close-modal {
    color: #e2e8f0 !important;
}

.dark-mode .notification {
    background: #334155 !important;
    color: #e2e8f0 !important;
}

/* Dark Mode Toggle Switch */
.dark-mode-toggle-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
}

.dark-mode-switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
}

.dark-mode-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #334155;
    transition: .4s;
    border-radius: 34px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 8px;
}

.slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
    border-radius: 50%;
    z-index: 2;
}

input:checked + .slider {
    background-color: #f59e0b;
}

input:checked + .slider:before {
    transform: translateX(26px);
}

.slider i {
    font-size: 14px;
    z-index: 1;
}

.slider .fa-sun {
    color: #f59e0b;
}

.slider .fa-moon {
    color: #e2e8f0;
}

/* Dark mode for specific components */
.dark-mode .code-editor {
    background: #1e293b !important;
    color: #e2e8f0 !important;
}

.dark-mode .ai-chat {
    background: #334155 !important;
}

.dark-mode .message.ai-message {
    background: #475569 !important;
}

.dark-mode .message.user-message {
    background: #0ea5e9 !important;
}

.dark-mode .proctoring-alert {
    background: #d97706 !important;
    color: #0f172a !important;
}

/* Chart dark mode */
.dark-mode .chart-container {
    background: #1e293b !important;
}

/* Assessment interface dark mode */
.dark-mode .assessment-interface {
    background: #1e293b !important;
}

.dark-mode .interview-report {
    background: #1e293b !important;
}

.dark-mode .score-circle {
    background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%) !important;
}

/* Analytics dark mode */
.dark-mode .analytics-card {
    background: #334155 !important;
}

.dark-mode .stat-card {
    background: #475569 !important;
    color: #e2e8f0 !important;
}

/* Learning center dark mode */
.dark-mode .learning-content {
    background: #1e293b !important;
}

.dark-mode .course-card {
    background: #334155 !important;
}

/* Responsive dark mode adjustments */
@media (max-width: 768px) {
    .dark-mode-toggle-container {
        top: 10px;
        right: 10px;
    }
    
    .dark-mode-switch {
        width: 50px;
        height: 28px;
    }
    
    .slider:before {
        height: 20px;
        width: 20px;
        left: 4px;
        bottom: 4px;
    }
    
    input:checked + .slider:before {
        transform: translateX(22px);
    }
    
    .slider i {
        font-size: 12px;
    }
}
`;

// Add dark mode styles to the page
function addDarkModeStyles() {
  if (!document.getElementById('dark-mode-styles')) {
    const styleElement = document.createElement('style');
    styleElement.id = 'dark-mode-styles';
    styleElement.textContent = darkModeStyles;
    document.head.appendChild(styleElement);
  }
}

// Update charts for dark mode
function updateChartsForDarkMode(isDark) {
  // This would update Chart.js configurations for dark mode
  if (typeof Chart !== 'undefined') {
    // Update existing charts
    Chart.helpers.each(Chart.instances, function(instance) {
      instance.options.scales.x.grid.color = isDark ? '#334155' : '#e5e7eb';
      instance.options.scales.y.grid.color = isDark ? '#334155' : '#e5e7eb';
      instance.options.scales.x.ticks.color = isDark ? '#e2e8f0' : '#374151';
      instance.options.scales.y.ticks.color = isDark ? '#e2e8f0' : '#374151';
      instance.update();
    });
  }
}

// Update code editors for dark mode
function updateCodeEditorsForDarkMode(isDark) {
  const codeEditors = document.querySelectorAll('.code-editor');
  codeEditors.forEach(editor => {
    if (isDark) {
      editor.style.backgroundColor = '#1e293b';
      editor.style.color = '#e2e8f0';
      editor.style.borderColor = '#475569';
    } else {
      editor.style.backgroundColor = '#f8fafc';
      editor.style.color = '#1f2937';
      editor.style.borderColor = '#d1d5db';
    }
  });
}

// Update custom elements for dark mode
function updateCustomElementsForDarkMode(isDark) {
  // Update any custom elements that need special handling
  const customElements = document.querySelectorAll('[data-dark-mode]');
  customElements.forEach(element => {
    const darkValue = element.getAttribute('data-dark-mode');
    const lightValue = element.getAttribute('data-light-mode');
    
    if (isDark && darkValue) {
      element.style.backgroundColor = darkValue;
    } else if (lightValue) {
      element.style.backgroundColor = lightValue;
    }
  });
}

// Log dark mode event for analytics
function logDarkModeEvent(isDark) {
  // Simulate analytics event
  if (typeof gtag !== 'undefined') {
    gtag('event', 'dark_mode_toggle', {
      'event_category': 'preferences',
      'event_label': isDark ? 'dark' : 'light'
    });
  }
  
  // Custom analytics
  console.log('Dark mode toggled:', isDark ? 'dark' : 'light');
}

// Detect system preference and auto-enable dark mode
function detectSystemTheme() {
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    // System prefers dark mode
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    if (darkModeToggle && !darkModeToggle.checked) {
      // Only auto-enable if user hasn't made a choice
      const hasUserPreference = localStorage.getItem('darkMode') !== null;
      if (!hasUserPreference) {
        darkModeToggle.checked = true;
        document.body.classList.add('dark-mode');
        localStorage.setItem('darkMode', 'true');
      }
    }
  }
}

// Listen for system theme changes
function watchSystemTheme() {
  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
      const darkModeToggle = document.getElementById('dark-mode-toggle');
      const hasUserPreference = localStorage.getItem('darkMode') !== null;
      
      // Only auto-switch if user hasn't set a preference
      if (!hasUserPreference) {
        if (e.matches) {
          darkModeToggle.checked = true;
          document.body.classList.add('dark-mode');
        } else {
          darkModeToggle.checked = false;
          document.body.classList.remove('dark-mode');
        }
      }
    });
  }
}

// Enhanced initialization function
function initializeDarkMode() {
  addDarkModeStyles();
  initDarkMode();
  detectSystemTheme();
  watchSystemTheme();
}

// Call this when the page loads
document.addEventListener('DOMContentLoaded', function() {
  initializeDarkMode();
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    initDarkMode,
    initializeDarkMode,
    detectSystemTheme,
    watchSystemTheme
  };
}