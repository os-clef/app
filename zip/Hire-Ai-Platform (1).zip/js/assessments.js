// Assessment functionality
let assessmentTimer;
let assessmentTimeRemaining = 3 * 60 * 60; // 3 hours in seconds

document.addEventListener('DOMContentLoaded', function() {
  // Set up assessment event listeners
  setupAssessmentEventListeners();
});

// Set up assessment event listeners
function setupAssessmentEventListeners() {
  // Proctoring simulation - detect tab switching
  document.addEventListener('visibilitychange', function() {
    if (document.hidden && document.getElementById('assessment-interface').classList.contains('active-page')) {
      // User switched tabs - show warning
      document.getElementById('timer').style.color = 'var(--danger)';
      showNotification('Warning: Tab switching detected! Continued violations may result in assessment termination.', 'warning');
      
      // Reset color after 2 seconds
      setTimeout(() => {
        document.getElementById('timer').style.color = '';
      }, 2000);
    }
  });
}

// Start assessment timer
function startAssessmentTimer(duration) {
  assessmentTimeRemaining = duration;
  clearInterval(assessmentTimer);
  
  assessmentTimer = setInterval(function() {
    const hours = Math.floor(assessmentTimeRemaining / 3600);
    const minutes = Math.floor((assessmentTimeRemaining % 3600) / 60);
    const seconds = assessmentTimeRemaining % 60;
    
    document.getElementById('timer').textContent =
      `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    if (assessmentTimeRemaining <= 0) {
      clearInterval(assessmentTimer);
      showNotification('Time is up! Your assessment has been automatically submitted.', 'info');
      endAssessment();
    } else {
      assessmentTimeRemaining--;
      
      // Change color when less than 10 minutes remaining
      if (assessmentTimeRemaining < 600) {
        document.getElementById('timer').style.color = 'var(--warning)';
      }
      
      // Change color when less than 5 minutes remaining
      if (assessmentTimeRemaining < 300) {
        document.getElementById('timer').style.color = 'var(--danger)';
      }
    }
  }, 1000);
}

// Pause assessment timer
function pauseAssessmentTimer() {
  clearInterval(assessmentTimer);
}

// Resume assessment timer
function resumeAssessmentTimer() {
  startAssessmentTimer(assessmentTimeRemaining);
}

// Simulate proctoring status changes
function simulateProctoring() {
  const proctoringItems = document.querySelectorAll('.proctoring-item');
  
  // Randomly change status of proctoring items
  setInterval(() => {
    proctoringItems.forEach(item => {
      if (Math.random() > 0.8) { // 20% chance to toggle status
        item.classList.toggle('active');
      }
    });
  }, 5000);
}

// Initialize proctoring simulation when assessment starts
function initProctoring() {
  simulateProctoring();
}