An animation created using Canvas and D3 to show how a Red-Black binary tree works. The animation shows how the tree allocates new nodes in the tree and its self-balancing property.

Four rules of Red-Black trees (note the order):

1. Each node in the tree is either Red or Black.
2. The root node is always black.
3. 2 Red nodes cannot be consecutive, meaning a Red node must have a Black parent, and a Red node's children must be Black.
4. Every path from a root node to a leaf (edge) node must pass through the same number of Black nodes.