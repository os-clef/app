// Main application functionality
document.addEventListener('DOMContentLoaded', function() {
  // Initialize the application
  initApp();
  
  // Set up event listeners
  setupEventListeners();
  
  // Load initial data
  loadInitialData();
});

// Initialize the application
function initApp() {
  // Show the home page by default
  showPage('home');
  
  // Animate progress bars
  animateProgressBars();
}

// Set up all event listeners
function setupEventListeners() {
  // Navigation links
  document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const page = this.getAttribute('data-page');
      showPage(page);
      
      // Update active nav link
      document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Mobile menu toggle
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener('click', toggleMobileMenu);
  }
  
  // Candidate and Employer buttons
  document.getElementById('candidate-btn').addEventListener('click', function() {
    showUserDashboard();
  });
  
  document.getElementById('employer-btn').addEventListener('click', function() {
    showCompanyDashboard();
  });
  
  // User dashboard sidebar tabs
  document.querySelectorAll('.sidebar-menu a').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const tab = this.getAttribute('data-tab');
      showUserTab(tab);
      
      // Update active sidebar link
      document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Company dashboard sidebar tabs
  document.querySelectorAll('.sidebar-menu a[data-company-tab]').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const tab = this.getAttribute('data-company-tab');
      showCompanyTab(tab);
      
      // Update active sidebar link
      document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Learning center tabs
  document.querySelectorAll('.tab-btn[data-learning-tab]').forEach(btn => {
    btn.addEventListener('click', function() {
      const tab = this.getAttribute('data-learning-tab');
      showLearningTab(tab);
      
      // Update active tab button
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Assessment tabs
  document.querySelectorAll('.assessment-tab-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const tab = this.getAttribute('data-assessment-tab');
      showAssessmentTab(tab);
      
      // Update active tab button
      document.querySelectorAll('.assessment-tab-btn').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });
  
  // Update skills button
  document.getElementById('update-skills-btn').addEventListener('click', function() {
    updateSkills();
  });
  
  // Refresh jobs button
  document.getElementById('refresh-jobs-btn').addEventListener('click', function() {
    refreshJobs();
  });
  
  // Add skill button
  document.getElementById('add-skill-btn').addEventListener('click', function() {
    addNewSkill();
  });
  
  // Send message to AI coach
  document.getElementById('send-message-btn').addEventListener('click', function() {
    sendMessageToCoach();
  });
  
  // Enter key for AI coach chat
  document.getElementById('coach-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendMessageToCoach();
    }
  });
  
  // Edit profile button
  document.getElementById('edit-profile-btn').addEventListener('click', function() {
    editProfile();
  });
  
  // Post job button
  document.getElementById('post-job-btn').addEventListener('click', function() {
    postNewJob();
  });
  
  // Create job button
  document.getElementById('create-job-btn').addEventListener('click', function() {
    createNewJob();
  });
  
  // Save settings button
  document.getElementById('save-settings-btn').addEventListener('click', function() {
    saveCompanySettings();
  });
  
  // Assessment control buttons
  document.getElementById('pause-assessment-btn').addEventListener('click', function() {
    togglePauseAssessment();
  });
  
  document.getElementById('end-assessment-btn').addEventListener('click', function() {
    confirmEndAssessment();
  });
  
  document.getElementById('hint-btn').addEventListener('click', function() {
    requestHint();
  });
  
  document.getElementById('next-question-btn').addEventListener('click', function() {
    nextQuestion();
  });
  
  document.getElementById('format-code-btn').addEventListener('click', function() {
    formatCode();
  });
  
  document.getElementById('run-code-btn').addEventListener('click', function() {
    runCode();
  });
  
  document.getElementById('submit-code-btn').addEventListener('click', function() {
    submitSolution();
  });
  
  document.getElementById('send-assessment-message-btn').addEventListener('click', function() {
    sendAssessmentMessage();
  });
  
  // Enter key for assessment chat
  document.getElementById('assessment-chat-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendAssessmentMessage();
    }
  });
  
  // Candidate filter change
  document.getElementById('candidate-filter').addEventListener('change', function() {
    filterCandidates(this.value);
  });
  
  // Analytics range change
  document.getElementById('analytics-range').addEventListener('change', function() {
    updateAnalytics(this.value);
  });
}

// Load initial data for the application
function loadInitialData() {
  // Load jobs for user dashboard
  loadJobs();
  
  // Load assessments for user dashboard
  loadAssessments();
  
  // Load skills for user dashboard
  loadSkills();
  
  // Load courses for learning center
  loadCourses();
  
  // Load practice challenges
  loadPracticeChallenges();
  
  // Load company activities
  loadCompanyActivities();
  
  // Load jobs for company dashboard
  loadCompanyJobs();
  
  // Load candidates for company dashboard
  loadCandidates();
}

// Show a specific page
function showPage(page) {
  // Hide all pages
  document.querySelectorAll('.active-page').forEach(el => {
    el.classList.remove('active-page');
  });
  
  // Show the requested page
  if (page === 'home') {
    document.querySelector('.hero').classList.add('active-page');
  } else if (page === 'features') {
    // For demo, just show home page
    document.querySelector('.hero').classList.add('active-page');
  } else if (page === 'assessment') {
    // For demo, just show user dashboard
    showUserDashboard();
  } else if (page === 'learning') {
    showUserDashboard();
    showUserTab('learning');
  } else if (page === 'company') {
    showCompanyDashboard();
  }
}

// Show user dashboard
function showUserDashboard() {
  document.querySelector('.hero').classList.remove('active-page');
  document.getElementById('user-dashboard').classList.add('active-page');
  document.getElementById('company-dashboard').classList.remove('active-page');
  document.getElementById('assessment-interface').classList.remove('active-page');
  
  // Show dashboard tab by default
  showUserTab('dashboard');
}

// Show company dashboard
function showCompanyDashboard() {
  document.querySelector('.hero').classList.remove('active-page');
  document.getElementById('user-dashboard').classList.remove('active-page');
  document.getElementById('company-dashboard').classList.add('active-page');
  document.getElementById('assessment-interface').classList.remove('active-page');
  
  // Show overview tab by default
  showCompanyTab('overview');
}

// Show a specific tab in user dashboard
function showUserTab(tab) {
  // Hide all tab contents
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
  });
  
  // Show the requested tab
  document.getElementById(`${tab}-tab`).classList.add('active');
}

// Show a specific tab in company dashboard
function showCompanyTab(tab) {
  // Hide all tab contents
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
  });
  
  // Show the requested tab
  document.getElementById(`${tab}-tab`).classList.add('active');
}

// Show a specific learning tab
function showLearningTab(tab) {
  // Hide all learning contents
  document.querySelectorAll('.learning-content').forEach(content => {
    content.classList.remove('active');
  });
  
  // Show the requested tab
  document.getElementById(`${tab}-content`).classList.add('active');
}

// Show a specific assessment tab
function showAssessmentTab(tab) {
  // Hide all assessment contents
  document.querySelectorAll('.assessment-tab-content').forEach(content => {
    content.classList.remove('active');
  });
  
  // Show the requested tab
  document.getElementById(`${tab}-tab`).classList.add('active');
}

// Toggle mobile menu
function toggleMobileMenu() {
  const navLinks = document.querySelector('.nav-links');
  const authButtons = document.querySelector('.auth-buttons');
  
  navLinks.classList.toggle('active');
  authButtons.classList.toggle('active');
}

// Animate progress bars
function animateProgressBars() {
  const progressBars = document.querySelectorAll('.progress-bar');
  
  progressBars.forEach(bar => {
    const width = bar.style.width;
    bar.style.width = '0';
    
    setTimeout(() => {
      bar.style.width = width;
    }, 500);
  });
}

// Update skills (demo function)
function updateSkills() {
  showNotification('Skills updated successfully!', 'success');
  
  // Simulate skill improvement
  const skills = [
    { selector: '.html-bar', newWidth: '90%' },
    { selector: '.css-bar', newWidth: '85%' },
    { selector: '.js-bar', newWidth: '95%' },
    { selector: '.react-bar', newWidth: '85%' }
  ];
  
  skills.forEach(skill => {
    const bar = document.querySelector(skill.selector);
    bar.style.width = skill.newWidth;
    
    // Update percentage text
    const skillItem = bar.closest('.skill-item');
    const percentageSpan = skillItem.querySelector('.skill-info span:last-child');
    percentageSpan.textContent = skill.newWidth;
  });
}

// Refresh jobs (demo function)
function refreshJobs() {
  showNotification('Jobs refreshed!', 'success');
  loadJobs();
}

// Add new skill (demo function)
function addNewSkill() {
  const skillName = prompt('Enter the name of the new skill:');
  if (skillName) {
    const skillLevel = prompt('Enter your proficiency level (0-100):');
    if (skillLevel && !isNaN(skillLevel) && skillLevel >= 0 && skillLevel <= 100) {
      // In a real app, you would add this to the database
      showNotification(`Skill "${skillName}" added with ${skillLevel}% proficiency!`, 'success');
      
      // Reload skills to show the new one
      loadSkills();
    } else {
      showNotification('Please enter a valid number between 0 and 100.', 'error');
    }
  }
}

// Send message to AI coach (demo function)
function sendMessageToCoach() {
  const input = document.getElementById('coach-input');
  const message = input.value.trim();
  
  if (message) {
    // Add user message to chat
    addChatMessage(message, 'user');
    
    // Clear input
    input.value = '';
    
    // Simulate AI response after a delay
    setTimeout(() => {
      const responses = [
        "That's a great question! Let me explain how to improve that skill.",
        "I'd recommend practicing with our interactive exercises to master that concept.",
        "Based on your current skill level, I suggest focusing on the fundamentals first.",
        "I've noticed you're making good progress! Keep up the good work.",
        "Let me share some resources that will help you with that topic."
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      addChatMessage(randomResponse, 'ai');
    }, 1000);
  }
}

// Send message during assessment (demo function)
function sendAssessmentMessage() {
  const input = document.getElementById('assessment-chat-input');
  const message = input.value.trim();
  
  if (message) {
    // Add user message to chat
    addAssessmentChatMessage(message, 'user');
    
    // Clear input
    input.value = '';
    
    // Simulate AI response after a delay
    setTimeout(() => {
      const responses = [
        "I can help with that! Remember to use semantic HTML tags for better accessibility.",
        "For that requirement, I'd suggest using CSS Grid for the layout.",
        "Make sure your code is responsive for different screen sizes.",
        "Don't forget to test your solution in multiple browsers.",
        "I notice you're on the right track! Keep going."
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      addAssessmentChatMessage(randomResponse, 'ai');
    }, 1000);
  }
}

// Add message to AI coach chat
function addChatMessage(message, sender) {
  const chatMessages = document.getElementById('chat-messages');
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message', `${sender}-message`);
  
  if (sender === 'user') {
    messageDiv.innerHTML = `<strong>You:</strong> ${message}`;
  } else {
    messageDiv.innerHTML = `<strong>AI Coach:</strong> ${message}`;
  }
  
  chatMessages.appendChild(messageDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Add message to assessment chat
function addAssessmentChatMessage(message, sender) {
  const chatMessages = document.getElementById('assessment-chat-messages');
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message', `${sender}-message`);
  
  if (sender === 'user') {
    messageDiv.innerHTML = `<strong>You:</strong> ${message}`;
  } else {
    messageDiv.innerHTML = `<strong>AI Proctor:</strong> ${message}`;
  }
  
  chatMessages.appendChild(messageDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Edit profile (demo function)
function editProfile() {
  const name = prompt('Enter your full name:', document.getElementById('user-name').textContent);
  if (name) {
    document.getElementById('user-name').textContent = name;
  }
  
  const email = prompt('Enter your email:', document.getElementById('user-email').textContent);
  if (email) {
    document.getElementById('user-email').textContent = email;
  }
  
  const location = prompt('Enter your location:', document.getElementById('user-location').textContent);
  if (location) {
    document.getElementById('user-location').textContent = location;
  }
  
  showNotification('Profile updated successfully!', 'success');
}

// Post new job (demo function)
function postNewJob() {
  showNotification('New job posting feature would open a form in a real application.', 'info');
}

// Create new job (demo function)
function createNewJob() {
  showNotification('Job creation form would open in a real application.', 'info');
}

// Save company settings (demo function)
function saveCompanySettings() {
  showNotification('Company settings saved successfully!', 'success');
}

// Toggle pause assessment (demo function)
function togglePauseAssessment() {
  const btn = document.getElementById('pause-assessment-btn');
  const isPaused = btn.textContent.includes('Resume');
  
  if (isPaused) {
    btn.innerHTML = '<i class="fas fa-pause"></i> Pause';
    btn.classList.remove('btn-success');
    btn.classList.add('btn-warning');
    showNotification('Assessment resumed!', 'success');
  } else {
    btn.innerHTML = '<i class="fas fa-play"></i> Resume';
    btn.classList.remove('btn-warning');
    btn.classList.add('btn-success');
    showNotification('Assessment paused!', 'warning');
  }
}

// Confirm end assessment
function confirmEndAssessment() {
  showConfirmationModal(
    'End Assessment',
    'Are you sure you want to end this assessment? Your progress will be saved.',
    endAssessment
  );
}

// End assessment (demo function)
function endAssessment() {
  showUserDashboard();
  showNotification('Assessment ended successfully! Your results have been saved.', 'success');
}

// Request hint (demo function)
function requestHint() {
  const hints = [
    "Use <header> for the top section of your page.",
    "Consider using <nav> for navigation links.",
    "<main> should contain the primary content of your page.",
    "Use <aside> for sidebar content.",
    "<footer> is perfect for contact information at the bottom."
  ];
  
  const randomHint = hints[Math.floor(Math.random() * hints.length)];
  addAssessmentChatMessage(`Hint: ${randomHint}`, 'ai');
}

// Next question (demo function)
function nextQuestion() {
  const currentDay = parseInt(document.getElementById('current-day').textContent);
  const totalDays = parseInt(document.getElementById('total-days').textContent);
  
  if (currentDay < totalDays) {
    document.getElementById('current-day').textContent = currentDay + 1;
    document.getElementById('assessment-title').textContent =
      document.getElementById('assessment-title').textContent.replace(
        `Day ${currentDay}`, `Day ${currentDay + 1}`
      );
    
    // Update question content
    document.querySelector('.question-card h3').textContent = `Question ${currentDay + 1}: CSS Layout Challenge`;
    document.querySelector('.question-card p').textContent =
      'Create a responsive layout using CSS Grid and Flexbox. The layout should adapt to different screen sizes.';
    
    showNotification('Moving to next question!', 'success');
  } else {
    showNotification('This is the final question!', 'info');
  }
}

// Format code (demo function)
function formatCode() {
  showNotification('Code formatted!', 'success');
  // In a real application, this would use a code formatting library
}

// Run code (demo function)
function runCode() {
  showNotification('Code executed! Output would be displayed in a real application.', 'info');
}

// Submit solution (demo function)
function submitSolution() {
  // Simulate scoring
  const score = Math.floor(Math.random() * 20) + 80; // Random score between 80-100
  const currentScore = parseInt(document.getElementById('current-score').textContent);
  document.getElementById('current-score').textContent = currentScore + score > 100 ? 100 : currentScore + score;
  
  showNotification(`Solution submitted! You scored ${score} points.`, 'success');
}

// Filter candidates (demo function)
function filterCandidates(filter) {
  showNotification(`Filtering candidates by: ${filter}`, 'info');
  // In a real application, this would filter the candidate list
}

// Update analytics (demo function)
function updateAnalytics(range) {
  showNotification(`Analytics updated for: ${range}`, 'info');
  // In a real application, this would update the charts with new data
}

// Show notification
function showNotification(message, type) {
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
        <span>${message}</span>
        <button class="close-notification">&times;</button>
    `;
  
  // Add styles for notification
  if (!document.querySelector('.notification-styles')) {
    const styles = document.createElement('style');
    styles.className = 'notification-styles';
    styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 5px;
                color: white;
                z-index: 10000;
                display: flex;
                align-items: center;
                justify-content: space-between;
                min-width: 300px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                animation: slideIn 0.3s ease-out;
            }
            .notification-success { background: var(--success); }
            .notification-error { background: var(--danger); }
            .notification-warning { background: var(--warning); }
            .notification-info { background: var(--primary); }
            .close-notification {
                background: none;
                border: none;
                color: white;
                font-size: 1.2rem;
                cursor: pointer;
                margin-left: 10px;
            }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
    document.head.appendChild(styles);
  }
  
  // Add to page
  document.body.appendChild(notification);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    notification.remove();
  }, 5000);
  
  // Close button functionality
  notification.querySelector('.close-notification').addEventListener('click', () => {
    notification.remove();
  });
}

// Show confirmation modal
function showConfirmationModal(title, message, confirmCallback) {
  document.getElementById('confirmation-title').textContent = title;
  document.getElementById('confirmation-message').textContent = message;
  document.getElementById('confirmation-modal').classList.add('active');
  
  // Set up confirm button
  const confirmBtn = document.getElementById('confirm-action-btn');
  confirmBtn.onclick = function() {
    document.getElementById('confirmation-modal').classList.remove('active');
    if (confirmCallback) confirmCallback();
  };
  
  // Set up cancel button
  document.getElementById('cancel-confirmation-btn').onclick = function() {
    document.getElementById('confirmation-modal').classList.remove('active');
  };
  
  // Close modal when clicking the X
  document.getElementById('close-confirmation-modal').onclick = function() {
    document.getElementById('confirmation-modal').classList.remove('active');
  };
}

// Load jobs for user dashboard
function loadJobs() {
  const jobs = [
  {
    title: "Frontend Developer",
    company: "Google",
    match: 72,
    skills: { html: 96, css: 95, js: 90 }
  },
  {
    title: "React Developer",
    company: "Meta",
    match: 68,
    skills: { react: 90, js: 85, css: 80 }
  },
  {
    title: "Full Stack Developer",
    company: "Amazon",
    match: 65,
    skills: { js: 88, node: 85, react: 80 }
  },
  {
    title: "UI/UX Designer",
    company: "Apple",
    match: 60,
    skills: { design: 90, figma: 85, css: 80 }
  }];
  
  const jobsGrid = document.getElementById('jobs-grid');
  jobsGrid.innerHTML = '';
  
  jobs.forEach(job => {
    const jobCard = document.createElement('div');
    jobCard.className = 'job-card';
    jobCard.innerHTML = `
            <h4>${job.title} - ${job.company}</h4>
            <span class="match-score">Match: ${job.match}%</span>
            <p>Required: ${Object.entries(job.skills).map(([skill, score]) => `${skill} ${score}%`).join(', ')}</p>
            <button class="btn btn-primary start-assessment-btn" data-job='${JSON.stringify(job)}'>Start Assessment</button>
        `;
    jobsGrid.appendChild(jobCard);
  });
  
  // Add event listeners to start assessment buttons
  document.querySelectorAll('.start-assessment-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const job = JSON.parse(this.getAttribute('data-job'));
      startAssessment(job);
    });
  });
}

// Load assessments for user dashboard
function loadAssessments() {
  const assessments = [
    { company: "Google", position: "Frontend Developer", status: "In Progress", day: 3, score: 75 },
    { company: "Meta", position: "React Developer", status: "Completed", day: 7, score: 88 },
    { company: "Amazon", position: "Full Stack Developer", status: "Not Started", day: 0, score: 0 }
  ];
  
  const assessmentsList = document.getElementById('assessments-list');
  assessmentsList.innerHTML = '';
  
  assessments.forEach(assessment => {
    const assessmentItem = document.createElement('div');
    assessmentItem.className = 'assessment-item';
    assessmentItem.innerHTML = `
            <div class="assessment-info">
                <h4>${assessment.company} - ${assessment.position}</h4>
                <p>Status: ${assessment.status} | Day: ${assessment.day}/7 | Score: ${assessment.score}/100</p>
            </div>
            <div class="assessment-actions">
                ${assessment.status === 'In Progress' ? 
                    '<button class="btn btn-primary continue-assessment-btn">Continue</button>' : 
                    assessment.status === 'Completed' ? 
                    '<button class="btn btn-outline view-results-btn">View Results</button>' :
                    '<button class="btn btn-primary start-assessment-btn">Start</button>'
                }
            </div>
        `;
    assessmentsList.appendChild(assessmentItem);
  });
}

// Load skills for user dashboard
function loadSkills() {
  const skills = [
    { name: "HTML", level: 85 },
    { name: "CSS", level: 78 },
    { name: "JavaScript", level: 92 },
    { name: "React", level: 80 },
    { name: "Node.js", level: 70 },
    { name: "Python", level: 65 }
  ];
  
  const skillsGrid = document.getElementById('skills-grid');
  skillsGrid.innerHTML = '';
  
  skills.forEach(skill => {
    const skillCard = document.createElement('div');
    skillCard.className = 'skill-card';
    skillCard.innerHTML = `
            <h4>${skill.name}</h4>
            <div class="progress-container">
                <div class="progress-bar" style="width: ${skill.level}%"></div>
            </div>
            <span>${skill.level}%</span>
            <button class="btn btn-outline improve-skill-btn">Improve</button>
        `;
    skillsGrid.appendChild(skillCard);
  });
}

// Load courses for learning center
function loadCourses() {
  const courses = [
    { title: "HTML Mastery", progress: 65, description: "Advanced semantic HTML, accessibility, and best practices" },
    { title: "CSS Grid & Flexbox", progress: 40, description: "Modern layout techniques for responsive design" },
    { title: "JavaScript Advanced", progress: 20, description: "ES6+, async programming, and modern patterns" },
    { title: "React Fundamentals", progress: 10, description: "Component-based UI development with React" }
  ];
  
  const coursesGrid = document.getElementById('courses-grid');
  coursesGrid.innerHTML = '';
  
  courses.forEach(course => {
    const courseCard = document.createElement('div');
    courseCard.className = 'course-card';
    courseCard.innerHTML = `
            <h4>${course.title}</h4>
            <p>${course.description}</p>
            <div class="progress-container">
                <div class="progress-bar" style="width: ${course.progress}%"></div>
            </div>
            <span>${course.progress}% Complete</span>
            <button class="btn btn-primary continue-course-btn">Continue</button>
        `;
    coursesGrid.appendChild(courseCard);
  });
}

// Load practice challenges
function loadPracticeChallenges() {
  const challenges = [
    { title: "Build a Responsive Navbar", type: "HTML/CSS", difficulty: "Beginner" },
    { title: "Create a Todo App", type: "JavaScript", difficulty: "Intermediate" },
    { title: "API Integration", type: "Fetch & Async", difficulty: "Advanced" },
    { title: "CSS Animation", type: "CSS", difficulty: "Intermediate" }
  ];
  
  const practiceChallenges = document.getElementById('practice-challenges');
  practiceChallenges.innerHTML = '';
  
  challenges.forEach(challenge => {
    const challengeCard = document.createElement('div');
    challengeCard.className = 'challenge-card';
    challengeCard.innerHTML = `
            <h4>${challenge.title}</h4>
            <p>Type: ${challenge.type} | Difficulty: ${challenge.difficulty}</p>
            <button class="btn btn-primary start-challenge-btn">Start Challenge</button>
        `;
    practiceChallenges.appendChild(challengeCard);
  });
}

// Load company activities
function loadCompanyActivities() {
  const activities = [
    { action: "New application received", candidate: "John Smith", position: "Frontend Developer", time: "10 minutes ago" },
    { action: "Assessment completed", candidate: "Sarah Johnson", position: "React Developer", time: "1 hour ago" },
    { action: "Interview scheduled", candidate: "Michael Brown", position: "Full Stack Developer", time: "2 hours ago" },
    { action: "Offer sent", candidate: "Emily Davis", position: "UI/UX Designer", time: "1 day ago" }
  ];
  
  const activityList = document.getElementById('activity-list');
  activityList.innerHTML = '';
  
  activities.forEach(activity => {
    const activityItem = document.createElement('div');
    activityItem.className = 'activity-item';
    activityItem.innerHTML = `
            <div class="activity-content">
                <strong>${activity.action}</strong> for <strong>${activity.candidate}</strong> (${activity.position})
            </div>
            <div class="activity-time">${activity.time}</div>
        `;
    activityList.appendChild(activityItem);
  });
}

// Load company jobs
function loadCompanyJobs() {
  const jobs = [
    { title: "Frontend Developer", applications: 245, inAssessment: 45, status: "Active" },
    { title: "Backend Engineer", applications: 189, inAssessment: 32, status: "Active" },
    { title: "Data Scientist", applications: 156, inAssessment: 28, status: "Active" },
    { title: "UI/UX Designer", applications: 98, inAssessment: 15, status: "Paused" }
  ];
  
  const jobsTable = document.querySelector('#jobs-table tbody');
  jobsTable.innerHTML = '';
  
  jobs.forEach(job => {
    const row = document.createElement('tr');
    row.innerHTML = `
            <td>${job.title}</td>
            <td>${job.applications}</td>
            <td>${job.inAssessment}</td>
            <td><span class="status-badge status-${job.status.toLowerCase()}">${job.status}</span></td>
            <td>
                <button class="btn btn-outline btn-sm view-candidates-btn">View Candidates</button>
                <button class="btn btn-outline btn-sm edit-job-btn">Edit</button>
            </td>
        `;
    jobsTable.appendChild(row);
  });
}

// Load candidates for company dashboard
function loadCandidates() {
  const candidates = [
    { name: "John Smith", position: "Frontend Developer", status: "In Assessment", score: 75, stage: "Day 3/7" },
    { name: "Sarah Johnson", position: "React Developer", status: "Assessment Complete", score: 88, stage: "Ready for Interview" },
    { name: "Michael Brown", position: "Full Stack Developer", status: "New Application", score: 0, stage: "Screening" },
    { name: "Emily Davis", position: "UI/UX Designer", status: "Interview Scheduled", score: 92, stage: "Final Round" }
  ];
  
  const candidatesList = document.getElementById('candidates-list');
  candidatesList.innerHTML = '';
  
  candidates.forEach(candidate => {
    const candidateCard = document.createElement('div');
    candidateCard.className = 'candidate-card';
    candidateCard.innerHTML = `
            <div class="candidate-info">
                <h4>${candidate.name}</h4>
                <p>Position: ${candidate.position}</p>
                <p>Status: ${candidate.status} | Score: ${candidate.score}/100</p>
                <p>Stage: ${candidate.stage}</p>
            </div>
            <div class="candidate-actions">
                <button class="btn btn-outline btn-sm view-profile-btn">View Profile</button>
                <button class="btn btn-primary btn-sm take-action-btn">Take Action</button>
            </div>
        `;
    candidatesList.appendChild(candidateCard);
  });
}

// Start assessment for a specific job
function startAssessment(job) {
  document.querySelector('.hero').classList.remove('active-page');
  document.getElementById('user-dashboard').classList.remove('active-page');
  document.getElementById('company-dashboard').classList.remove('active-page');
  document.getElementById('assessment-interface').classList.add('active-page');
  
  // Set assessment title
  document.getElementById('assessment-title').textContent = `${job.title} Assessment - ${job.company} - Day 1/7`;
  
  // Reset assessment state
  document.getElementById('current-day').textContent = '1';
  document.getElementById('current-score').textContent = '0';
  
  // Start timer
  startAssessmentTimer(3 * 60 * 60); // 3 hours in seconds
  
  showNotification(`Starting assessment for ${job.title} at ${job.company}`, 'success');
}